package org.posts;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;

import com.posts.Post;

import service.PostsDAOImpl;
import service.Status;

@Path("posts")

public class MyResource {

	PostsDAOImpl impl = new PostsDAOImpl();

	@GET
	@Path("/authenticate")
	@Produces(MediaType.APPLICATION_JSON)
	public Post login(@Context HttpHeaders headers) {
		List<String> authHeaders = headers.getRequestHeader(HttpHeaders.AUTHORIZATION);
		System.out.println(authHeaders.get(0));
		 String base64Credentials =
		 authHeaders.get(0).substring("Basic".length()).trim();
		 String credentials = new
		 String(Base64.getDecoder().decode(base64Credentials),
		 Charset.forName("UTF-8"));
		 System.out.println(credentials);
		 final String[] values = credentials.split(":", 2);
		 System.out.println(values[0] + "," + values[1]);
		return new Post(1, ".", "..");

	}
	
	@Path("all")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Post> getPosts() {

		ArrayList<Post> list = (ArrayList<Post>) impl.getPosts();

		return list;
	}

	@Path("/{title}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public ArrayList<Post> getPost(@PathParam("title") String title) {

		ArrayList<Post> posts = impl.getPost(title);
		
		return posts;
	}

	@Path("/add")
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Post addPost(Post post) {

		post = impl.addPost(post);
		System.out.println("Added Posts's Id: " + post.id);
		return post;
	}

	@Path("update/{id}")
	@PUT
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Status updatePost(@PathParam("id") int id, Post post) {

		post.setId(id);
		Status s = impl.updatePost(post);

		return s;
	}

	@Path("delete/{id}")
	@DELETE
	@Produces(MediaType.APPLICATION_JSON)

	public Status deletePost(@PathParam("id") int id) {		
		Post post = new Post();
		post.setId(id);
		Status s = impl.deletePost(post);
		return s;
	}

}